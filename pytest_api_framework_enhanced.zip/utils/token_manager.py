import jwt
import requests
import time
from config.config import JWT_SECRET, ACCESS_TOKEN_URL
from utils.logger import logger

def generate_jwt():
    payload = {
        "iss": "your-client-id",
        "sub": "your-subject",
        "aud": "your-audience",
        "iat": int(time.time()),
        "exp": int(time.time()) + 300
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm="HS256")
    return token if isinstance(token, str) else token.decode()

def get_access_token():
    jwt_token = generate_jwt()
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "grant_type": "client_credentials",
        "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        "client_assertion": jwt_token
    }
    response = requests.post(ACCESS_TOKEN_URL, headers=headers, data=data)
    logger.info("Token response: %s", response.text)
    response.raise_for_status()
    return response.json().get("access_token")
