import requests
from utils.token_manager import get_access_token
from config.config import BASE_URL
from utils.logger import logger

def send_request(method, endpoint, headers=None, data=None, json=None, params=None):
    token = get_access_token()
    auth_headers = {
        "Authorization": f"Bearer {token}"
    }
    if headers:
        auth_headers.update(headers)

    url = f"{BASE_URL}{endpoint}"
    logger.info("Sending %s request to %s", method, url)
    logger.info("Headers: %s", auth_headers)
    logger.info("Payload: %s", json or data)

    response = requests.request(method, url, headers=auth_headers, data=data, json=json, params=params)

    logger.info("Response: %s", response.text)
    return response
