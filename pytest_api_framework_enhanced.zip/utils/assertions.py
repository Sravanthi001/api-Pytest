from jsonschema import validate, ValidationError

def assert_status_code(response, expected):
    assert response.status_code == expected, f"Expected {expected}, got {response.status_code}"

def assert_response_schema(response, schema):
    try:
        validate(instance=response.json(), schema=schema)
    except ValidationError as e:
        raise AssertionError(f"Schema validation failed: {e.message}")
