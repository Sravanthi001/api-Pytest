from utils.request_handler import send_request

def get_ce_data():
    return send_request("GET", "/ce")

def update_ce_data(payload):
    return send_request("PUT", "/ce", json=payload)
