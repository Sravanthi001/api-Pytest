from utils.request_handler import send_request

def get_workitems():
    return send_request("GET", "/workitems")

def create_workitem(payload):
    return send_request("POST", "/workitems", json=payload)
