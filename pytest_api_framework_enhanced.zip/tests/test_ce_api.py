from apis.ce_api import get_ce_data, update_ce_data
from utils.assertions import assert_status_code

def test_get_ce_data():
    response = get_ce_data()
    assert_status_code(response, 200)

def test_update_ce_data():
    response = update_ce_data({"field": "value"})
    assert_status_code(response, 200)
