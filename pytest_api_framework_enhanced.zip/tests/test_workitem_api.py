from apis.workitem_api import get_workitems, create_workitem
from data.workitem_payloads import valid_workitem
from schemas.workitem_schema import workitem_response_schema
from utils.assertions import assert_status_code, assert_response_schema

def test_get_workitems():
    response = get_workitems()
    assert_status_code(response, 200)

def test_create_workitem():
    response = create_workitem(valid_workitem())
    assert_status_code(response, 201)
    assert_response_schema(response, workitem_response_schema)
