workitem_response_schema = {
    "type": "object",
    "properties": {
        "id": {"type": "integer"},
        "title": {"type": "string"},
        "description": {"type": "string"}
    },
    "required": ["id", "title", "description"]
}
