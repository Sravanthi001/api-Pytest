# Enhanced Pytest API Framework

## Features
- JWT-based authentication
- Reusable API wrappers
- JSON schema validation
- Logging to file
- HTML report generation

## Usage
```bash
pip install -r requirements.txt
pytest
```

## Env Variables
```bash
export BASE_URL=https://api.example.com
export JWT_SECRET=your_jwt_secret
export ACCESS_TOKEN_URL=https://auth.example.com/token
```

Logs saved to `logs/test.log`  
Reports saved to `report.html`
