def valid_workitem():
    return {
        "title": "Sample WorkItem",
        "description": "Created during automation testing"
    }
