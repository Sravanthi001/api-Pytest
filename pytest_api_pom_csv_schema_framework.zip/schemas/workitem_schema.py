base_schema = {
    "type": "object",
    "properties": {
        "id": {"type": "integer"},
        "title": {"type": "string"},
        "description": {"type": "string"},
        "owner": {"type": "string"}
    },
    "required": []
}

def schema_for_scenario(required_fields):
    schema = base_schema.copy()
    schema["required"] = required_fields
    return schema
