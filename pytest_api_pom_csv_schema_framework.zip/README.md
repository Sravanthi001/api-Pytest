# API Automation Framework (POM + CSV + Schema Validation)

### ✅ How It Works:

**🔁 Test Flow**
- Tests in `tests/` folder call Page Objects from `pages/`
- Page Objects use `send_request()` from `utils/request_handler.py`
- It gets an access token using `utils/token_manager.py`
- CSV data is read via `data/workitem_data_reader.py` → becomes JSON payload
- Schema is built dynamically from `schemas/workitem_schema.py`
- Response is validated using `utils/assertions.py`
- Logs go to `logs/test.log`, and reports to `report.html`

### ▶️ Run
```bash
pip install -r requirements.txt
pytest
```

Set your environment:
```bash
export BASE_URL=https://your-api.com
export JWT_SECRET=your_jwt_secret
export ACCESS_TOKEN_URL=https://auth.your-api.com/token
```
