from utils.request_handler import send_request

class CEPage:

    def get_ce_data(self):
        return send_request("GET", "/ce")

    def update_ce_data(self, payload):
        return send_request("PUT", "/ce", json=payload)
