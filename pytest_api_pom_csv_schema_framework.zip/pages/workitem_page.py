from utils.request_handler import send_request

class WorkItemPage:

    def get_workitems(self):
        return send_request("GET", "/workitems")

    def create_workitem(self, payload):
        return send_request("POST", "/workitems", json=payload)
