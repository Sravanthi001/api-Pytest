import csv

def get_payloads_from_csv(file_path="data/workitem_data.csv"):
    with open(file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        return [dict(row) for row in reader]
