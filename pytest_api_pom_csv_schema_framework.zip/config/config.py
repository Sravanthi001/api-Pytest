import os

BASE_URL = os.getenv("BASE_URL", "https://api.example.com")
JWT_SECRET = os.getenv("JWT_SECRET", "your_jwt_secret")
ACCESS_TOKEN_URL = os.getenv("ACCESS_TOKEN_URL", "https://auth.example.com/token")
