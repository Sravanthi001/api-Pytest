from pages.workitem_page import WorkItemPage
from data.workitem_data_reader import get_payloads_from_csv
from schemas.workitem_schema import schema_for_scenario
from utils.assertions import assert_status_code, assert_response_schema

workitem_page = WorkItemPage()

def test_workitems_from_csv_with_schema():
    for payload in get_payloads_from_csv():
        response = workitem_page.create_workitem(payload)
        assert_status_code(response, 201)
        schema = schema_for_scenario(["id", "title", "description", "owner"])
        assert_response_schema(response, schema)
