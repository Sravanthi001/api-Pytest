from pages.ce_page import CEPage
from utils.assertions import assert_status_code

ce_page = CEPage()

def test_get_ce_data():
    response = ce_page.get_ce_data()
    assert_status_code(response, 200)

def test_update_ce_data():
    response = ce_page.update_ce_data({"field": "value"})
    assert_status_code(response, 200)
